"use strict";

const dateInput = document.getElementById("date");
const monthInput = document.getElementById("month");
const yearInput = document.getElementById("year");

const button = document.querySelector("button");
const Days = document.getElementById("dayLived");
const Month = document.getElementById("monthLived");
const Year = document.getElementById("yearLived");



//function for displaying output
function calculateAge() {
  const date = dateInput.value;
  const month = monthInput.value;
  const year = yearInput.value;

  console.log(date, month, year);

  const today = new Date();
  const todayDate = today.getDate();
  const todayMonth = today.getMonth();
  const todayYear = today.getFullYear();
  console.log(todayDate, todayMonth, todayYear);

  const outputdate = Math.abs(todayDate - date);
  const outputMonth = Math.abs(todayMonth - month);
  const outputYear = todayYear - year;

  Days.innerText = outputdate;
  Month.innerText = outputMonth;
  Year.innerText = outputYear;
}

button.addEventListener("click", calculateAge);
